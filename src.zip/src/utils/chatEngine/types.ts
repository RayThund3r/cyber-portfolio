// src/utils/chatEngine/types.ts

export type PersonaMode = 'HUMAN' | 'EXPERT';

export type TopicDomain =
  | 'GREETINGS'
  | 'SMALLTALK'
  | 'HARDWARE_REPAIR'
  | 'DESIGN_BRANDING'
  | 'WEB_DEV'
  | 'PRICING_RATES'
  | 'CONTACT'
  | 'PORTFOLIO'
  | 'SYSTEM'
  | 'GENERAL_QA'
  | 'AI_CHAT';

/** Where a reply came from. Shown as a small badge in the widget. */
export type ResponseSource =
  | 'rules'
  | 'knowledge'
  | 'web'
  | 'local-ai'
  | 'remote-ai'
  | 'system'
  | 'safety';

/** Site actions the chat can trigger (the widget broadcasts them as a window event). */
export type SystemAction =
  | 'SCROLL_TO_PROJECTS'
  | 'OPEN_CONTACT'
  | 'TOGGLE_THEME'
  | 'RESET_CHAT'
  | 'NONE';

export interface ConversationTurn {
  role: 'user' | 'assistant';
  text: string;
}

export interface SessionMemory {
  interactionCount: number;
  lastTopic: TopicDomain | string;
  userContext: Record<string, any>;
  conversationHistory: ConversationTurn[];
}

export interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  imageUrl?: string;
  time: string;
  source?: ResponseSource;
  streaming?: boolean;
  /** Set on replies the visitor can rate; rating teaches the retriever (per browser). */
  learn?: { query: string; entryId: string };
  rated?: 'up' | 'down';
}

export interface EngineOptions {
  /** Called with the full text so far while an AI model is streaming. */
  onToken?: (partialText: string) => void;
  signal?: AbortSignal;
}

export interface ProcessingResult {
  reply: string;
  updatedMemory: SessionMemory;
  imageUrl?: string;
  source: ResponseSource;
  suggestions?: string[];
  action?: SystemAction;
  /** Id of the knowledge entry used for the reply (lets the widget offer 👍/👎 learning). */
  matchedEntryId?: string;
}

export interface KnowledgeEntry {
  id: string;
  domain: TopicDomain;
  title: string;
  keywords: string[];
  /** Plain facts. Used as grounding context for the AI model. */
  content: string;
  /** Ready-made reply for HUMAN mode (used when no AI model is running). */
  reply: string;
  /** Ready-made reply for EXPERT mode. */
  expert: string;
  suggestions?: string[];
  /** Optional picture shown with the reply (restored from the original hot-PC / computers answers). */
  image?: string;
}

export interface KnowledgeHit {
  entry: KnowledgeEntry;
  score: number;
  /** 0..1 — share of the query's (rarity-weighted) terms found in this entry. */
  confidence: number;
}

export interface CachedAnswer {
  query: string;
  extract: string;
  title: string;
  imageUrl?: string;
  timestamp: number;
}

export interface UnansweredItem {
  query: string;
  timestamp: number;
}

/** Legacy shape (original learningEngine). Still exported for compatibility. */
export interface LearnedMemoryItem {
  pattern: string;
  mappedIntent: string;
  timestamp: number;
}

/** A visitor-confirmed link between a phrasing and a knowledge entry. */
export interface LearnedAlias {
  query: string;
  entryId: string;
  /** 1 = "that was helpful", -1 = "that was wrong" */
  polarity: 1 | -1;
  timestamp: number;
}
