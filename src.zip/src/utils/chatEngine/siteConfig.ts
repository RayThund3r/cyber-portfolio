// src/utils/chatEngine/siteConfig.ts
//
// EDIT THIS FILE. Everything the assistant "knows" about you and your business
// lives here and in knowledgeBase.ts. The AI model is told NOT to invent facts,
// so anything you want it to state confidently (prices, hours, links) goes here.

export const SITE = {
  assistantName: 'Cyber Assistant',
  ownerName: 'the owner',            // e.g. 'Spider' — used in the AI's persona
  location: 'Ndejje, Makindye Ssabagabo, Uganda',

  // Fill these in to let the assistant quote them. Leave '' to stay silent about them.
  whatsapp: '',                      // e.g. '+256 7XX XXX XXX'
  email: '',
  hours: '',                         // e.g. 'Mon–Sat, 8am–7pm'

  // Element ids on your page that the chat can scroll to.
  projectsElementId: 'projects',
  contactElementId: 'contact',

  services: [
    'Phone and PC hardware repair (screens, batteries, charging ports, motherboard-level faults, diagnostics)',
    'Graphic and brand design (logos, posters, brand identity, UI/UX in Figma)',
    'Embroidery and fabric-print file preparation (name lists, vector artwork, DST/PES formats)',
    'Web development (Next.js, React, Tailwind CSS, Framer Motion)',
  ],
};

export const FALLBACK_SUGGESTIONS = [
  'My device is not working',
  'I need a logo',
  'Build me a website',
  'Get a quote',
];
