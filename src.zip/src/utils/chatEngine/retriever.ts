// src/utils/chatEngine/retriever.ts
//
// Typo-tolerant BM25 retriever over the knowledge base. This replaces the old
// `keywords.some(kw => query.includes(kw))` check, which matched "hi" inside
// "this" and never understood paraphrases.

import { KnowledgeEntry, KnowledgeHit } from './types';
import { KNOWLEDGE } from './knowledgeBase';
import { tokens, tokenMatch, normalize } from './text';
import { getLearnedAliases } from './learningEngine';

const K1 = 1.4;
const B = 0.75;

interface IndexedDoc {
  entry: KnowledgeEntry;
  tf: Map<string, number>;
  length: number;
}

let index: IndexedDoc[] | null = null;
let df = new Map<string, number>();
let avgLen = 1;

function build(): IndexedDoc[] {
  const docs: IndexedDoc[] = KNOWLEDGE.map((entry) => {
    const tf = new Map<string, number>();
    const add = (ts: string[], weight: number) =>
      ts.forEach((t) => tf.set(t, (tf.get(t) || 0) + weight));
    add(tokens(entry.title), 3);
    entry.keywords.forEach((k) => add(tokens(k), 3));
    add(tokens(entry.content), 1);
    let length = 0;
    tf.forEach((v) => (length += v));
    return { entry, tf, length };
  });
  df = new Map();
  docs.forEach((d) => d.tf.forEach((_, term) => df.set(term, (df.get(term) || 0) + 1)));
  avgLen = docs.reduce((s, d) => s + d.length, 0) / Math.max(1, docs.length);
  return docs;
}

function jaccardSets(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 || b.size === 0) return 0;
  let inter = 0;
  a.forEach((x) => {
    if (b.has(x)) inter++;
  });
  return inter / (a.size + b.size - inter);
}

function idf(term: string, n: number): number {
  const d = df.get(term) || 0;
  return Math.log(1 + (n - d + 0.5) / (d + 0.5));
}

/** Frequency of query term in doc, allowing typos (exact match wins). */
function fuzzyTf(doc: IndexedDoc, qTerm: string): { tf: number; term: string } | null {
  const exact = doc.tf.get(qTerm);
  if (exact) return { tf: exact, term: qTerm };
  if (qTerm.length < 4) return null;
  let best: { tf: number; term: string } | null = null;
  doc.tf.forEach((v, term) => {
    if (tokenMatch(qTerm, term) && (!best || v > best.tf)) best = { tf: v, term };
  });
  return best;
}

export function searchKnowledge(query: string, limit = 3): KnowledgeHit[] {
  if (!index) index = build();
  const qTokens = Array.from(new Set(tokens(query)));
  if (qTokens.length === 0) return [];

  const n = index.length;
  const maxIdf = Math.log(1 + (n + 0.5) / 0.5);
  // Terms nobody has ever seen count as maximally rare → they lower confidence.
  const weights = qTokens.map((t) => (df.has(t) ? idf(t, n) : maxIdf));
  const totalWeight = weights.reduce((a, b) => a + b, 0) || 1;

  // What this visitor has taught us (👍 = "that phrasing means this entry", 👎 = "wrong entry").
  const qSet = new Set(qTokens);
  const learnedBoost = new Map<string, number>(); // entryId -> similarity of best 👍 alias
  const learnedPenalty = new Set<string>(); // entryIds with a close 👎 alias
  for (const a of getLearnedAliases()) {
    const sim = jaccardSets(qSet, new Set(tokens(a.query)));
    if (sim < 0.7) continue;
    if (a.polarity === 1) learnedBoost.set(a.entryId, Math.max(learnedBoost.get(a.entryId) || 0, sim));
    else learnedPenalty.add(a.entryId);
  }

  const hits: KnowledgeHit[] = index.map((doc) => {
    let score = 0;
    let matchedWeight = 0;
    qTokens.forEach((q, i) => {
      const m = fuzzyTf(doc, q);
      if (!m) return;
      const termIdf = idf(m.term, n);
      const norm = 1 - B + B * (doc.length / avgLen);
      score += termIdf * ((m.tf * (K1 + 1)) / (m.tf + K1 * norm));
      matchedWeight += weights[i];
    });

    // Small bonus when the whole normalised query appears as a keyword phrase.
    const nq = normalize(query);
    if (doc.entry.keywords.some((k) => normalize(k) === nq)) score *= 1.3;

    let confidence = matchedWeight / totalWeight;

    const boost = learnedBoost.get(doc.entry.id);
    if (boost) {
      score += 4 * boost;
      confidence = Math.max(confidence, 0.5 + 0.5 * boost);
    }
    if (learnedPenalty.has(doc.entry.id) && !boost) {
      score *= 0.25;
      confidence *= 0.5;
    }

    return { entry: doc.entry, score, confidence };
  });

  return hits
    .filter((h) => h.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

/** Expose for tests / hot reload. */
export function resetKnowledgeIndex(): void {
  index = null;
}
