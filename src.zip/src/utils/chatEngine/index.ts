// src/utils/chatEngine/index.ts
//
// Orchestrator. Pipeline (first match wins):
//
//   1. safety / policy gate
//   2. site actions        ("show me your projects", "open contact")
//   3. system handlers     (time, status, reset) + calculator (exact maths, never guessed)
//   4. small talk          ("sup", "m good", thanks, jokes, names...)
//   5. follow-ups          (bare "yes"/"ok" continue the current topic)
//   6. gibberish filter
//   7. LANGUAGE MODEL      (on-device WebLLM, or your self-hosted endpoint) grounded with
//                          knowledge-base facts + optional web context
//   8. no model running -> retriever answer -> web lookup -> smart fallback
//
// Steps 1-6 are instant and deterministic. Step 7 is what makes it ChatGPT-like.

import {
  EngineOptions,
  KnowledgeHit,
  PersonaMode,
  ProcessingResult,
  ResponseSource,
  SessionMemory,
  SystemAction,
  TopicDomain,
} from './types';
import { evaluateInputSafety } from './evaluator';
import { detectAction, actionReply } from './actions';
import { handleSystemQuery } from './systemHandlers';
import { handleSmallTalk, isAffirmative, isNegative, FOLLOW_UP_PROMPTS } from './smalltalk';
import { isGibberish, logUnanswered } from './learningEngine';
import { searchKnowledge } from './retriever';
import { searchWeb, looksLikeLookup, needsLiveData } from './webSearch';
import { tryCalculate, formatNumber } from './calc';
import { buildMessages } from './promptBuilder';
import { generateLocal, isLocalLLMReady, labelForModel, getLLMState } from './localLLM';
import { generateRemote, isRemoteLLMConfigured } from './remoteLLM';
import { FALLBACK_SUGGESTIONS } from './siteConfig';
import { normalize, tokens, truncate } from './text';

export function isAIAvailable(): boolean {
  return isLocalLLMReady() || isRemoteLLMConfigured();
}

function aiLabel(): string {
  if (isLocalLLMReady()) return `ON-DEVICE (${labelForModel(getLLMState().modelId)})`;
  if (isRemoteLLMConfigured()) return 'SELF-HOSTED';
  return 'OFF (rules + search)';
}

function finish(
  memory: SessionMemory,
  input: string,
  reply: string,
  source: ResponseSource,
  extra: {
    topic?: TopicDomain | string;
    learn?: Record<string, any>;
    imageUrl?: string;
    suggestions?: string[];
    action?: SystemAction;
    matchedEntryId?: string;
  } = {}
): ProcessingResult {
  return {
    reply,
    source,
    imageUrl: extra.imageUrl,
    suggestions: extra.suggestions,
    action: extra.action,
    matchedEntryId: extra.matchedEntryId,
    updatedMemory: {
      ...memory,
      interactionCount: memory.interactionCount + 1,
      lastTopic: extra.topic ?? memory.lastTopic,
      userContext: { ...memory.userContext, ...(extra.learn || {}) },
      conversationHistory: [
        ...memory.conversationHistory,
        { role: 'user' as const, text: input },
        { role: 'assistant' as const, text: reply },
      ].slice(-24),
    },
  };
}

/** Paraphrase hints so retrieval understands vague wording. */
function expandQuery(q: string, lastTopic: string): string {
  let out = q;
  // Only treat "how much" as a price question when nothing else in the sentence says what it is about
  // ("how much ram do I need" must stay a RAM question).
  if (/\bhow much (for|to|is|does|would|will)\b/i.test(out) || (/\bhow much\b/i.test(out) && tokens(out).length === 0)) {
    out += ' price cost';
  }
  // Very short follow-ups inherit the topic they follow ("what about screens?")
  if (tokens(out).length <= 1) {
    const hint: Record<string, string> = {
      HARDWARE_REPAIR: 'repair',
      DESIGN_BRANDING: 'design',
      WEB_DEV: 'website',
      PRICING_RATES: 'price',
    };
    if (hint[lastTopic]) out += ' ' + hint[lastTopic];
  }
  return out;
}

function trimToSentences(text: string, max = 650): string {
  if (text.length <= max) return text;
  const cut = text.slice(0, max);
  const lastStop = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('! '), cut.lastIndexOf('? '));
  return (lastStop > 200 ? cut.slice(0, lastStop + 1) : cut.trimEnd() + '…');
}

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T | null> {
  return Promise.race([p, new Promise<null>((r) => setTimeout(() => r(null), ms))]);
}

export async function processChatQuery(
  input: string,
  mode: PersonaMode,
  memory: SessionMemory,
  options: EngineOptions = {}
): Promise<ProcessingResult> {
  const raw = input.trim();
  const q = normalize(raw);
  const wordCount = q ? q.split(' ').length : 0;
  const name = memory.userContext?.name as string | undefined;

  // 1. Safety --------------------------------------------------------------
  const safety = evaluateInputSafety(raw, mode);
  if (!safety.isSafe) {
    return finish(memory, raw, safety.safeReply || 'Request blocked by policy.', 'safety');
  }

  // 2. Site actions (short commands only, so long messages that happen to
  //    contain "contact" are not hijacked) ------------------------------------
  const action = detectAction(raw);
  if (action !== 'NONE' && wordCount <= 8) {
    const reply = actionReply(action, mode);
    if (reply) {
      return finish(memory, raw, reply, 'system', { topic: 'SYSTEM', action });
    }
  }

  // 3. System handlers -----------------------------------------------------
  const sys = handleSystemQuery(raw, mode, aiLabel());
  if (sys) {
    return finish(memory, raw, sys.reply, 'system', { topic: 'SYSTEM', action: sys.action });
  }

  // 3b. Calculator ---------------------------------------------------------
  const calc = tryCalculate(raw);
  if (calc) {
    const result = Number.isFinite(calc.value) ? formatNumber(calc.value) : null;
    const reply = result
      ? mode === 'EXPERT'
        ? `CALC // ${calc.expr} = ${result}`
        : `${calc.expr} = **${result}** 🧮`
      : mode === 'EXPERT'
      ? 'CALC // Undefined result (division by zero or overflow).'
      : "That one's undefined (dividing by zero breaks maths) 😄 Try another calculation?";
    return finish(memory, raw, reply, 'system', { topic: 'GENERAL_QA' });
  }

  // 4. Small talk ----------------------------------------------------------
  const talk = handleSmallTalk(raw, mode, name);
  if (talk) {
    return finish(memory, raw, talk.reply, 'rules', {
      topic: talk.keepTopic ? memory.lastTopic : talk.topic,
      learn: talk.learn,
      suggestions: talk.suggestions,
    });
  }

  // 5. Bare yes / no -------------------------------------------------------
  if (isAffirmative(q)) {
    const fu = FOLLOW_UP_PROMPTS[memory.lastTopic as string];
    if (fu) {
      return finish(memory, raw, mode === 'EXPERT' ? fu.expert : fu.human, 'rules', { suggestions: fu.suggestions });
    }
    return finish(
      memory,
      raw,
      mode === 'EXPERT' ? 'SYS_PROMPT // Specify domain: [HARDWARE] [DESIGN] [WEB].' : 'Great! What would you like to talk about — a repair, a design, or a website?',
      'rules',
      { suggestions: FALLBACK_SUGGESTIONS }
    );
  }
  if (isNegative(q)) {
    return finish(
      memory,
      raw,
      mode === 'EXPERT' ? 'SYS_ACK // Standing by.' : 'No problem! I\'m here if you need anything else. 😊',
      'rules'
    );
  }

  // 6. Gibberish -----------------------------------------------------------
  if (isGibberish(raw)) {
    return finish(
      memory,
      raw,
      mode === 'EXPERT'
        ? 'SYS_INPUT_ERR // Unparseable character sequence.'
        : "Hmm, I couldn't make sense of that one 😄 Try asking in a sentence — for example \"my laptop won't turn on\" or \"I need a logo\".",
      'rules',
      { suggestions: FALLBACK_SUGGESTIONS }
    );
  }

  // Retrieval is used by both the LLM path (as grounding) and the rules path.
  const hits: KnowledgeHit[] = searchKnowledge(expandQuery(raw, memory.lastTopic as string), 3);
  const best = hits[0];
  const strong = !!best && best.confidence >= 0.5;

  // 7. Language model ------------------------------------------------------
  if (isAIAvailable()) {
    let webContext: { title: string; extract: string } | null = null;
    if (!strong && looksLikeLookup(raw)) {
      const web = await withTimeout(searchWeb(raw, mode, options.signal), 2500);
      if (web) webContext = { title: web.title, extract: web.extract };
    }

    const messages = buildMessages({ input: raw, mode, memory, hits, webContext });
    let partial = '';
    const onToken = (t: string) => {
      partial = t;
      options.onToken?.(t);
    };

    try {
      let text = '';
      let source: ResponseSource = 'local-ai';
      if (isLocalLLMReady()) {
        text = await generateLocal(messages, onToken, options.signal);
      } else {
        source = 'remote-ai';
        text = await generateRemote(messages, onToken, options.signal);
      }

      text = text.replace(/^(assistant|ai)\s*:\s*/i, '').trim();
      if (text.length >= 2) {
        return finish(memory, raw, text, source, {
          topic: best && best.confidence >= 0.4 ? best.entry.domain : 'AI_CHAT',
          suggestions: best && best.confidence >= 0.4 ? best.entry.suggestions : undefined,
          imageUrl: strong ? best?.entry.image : undefined,
        });
      }
    } catch (err) {
      if (options.signal?.aborted) {
        return finish(memory, raw, partial.trim() || 'Stopped.', isLocalLLMReady() ? 'local-ai' : 'remote-ai', { topic: 'AI_CHAT' });
      }
      console.warn('LLM generation failed, falling back to rules:', err);
    }
    // fall through to rule-based path
  }

  // 8a. Knowledge base answer ----------------------------------------------
  if (strong && best) {
    return finish(memory, raw, mode === 'EXPERT' ? best.entry.expert : best.entry.reply, 'knowledge', {
      topic: best.entry.domain,
      suggestions: best.entry.suggestions,
      imageUrl: best.entry.image,
      matchedEntryId: best.entry.id,
    });
  }

  // 8b. Web lookup ---------------------------------------------------------
  let lookupFailed = false;
  if (looksLikeLookup(raw)) {
    const web = await searchWeb(raw, mode, options.signal);
    if (web?.blockedReply) {
      return finish(memory, raw, web.blockedReply, 'safety');
    }
    if (web) {
      const body = trimToSentences(web.extract);
      const src = web.url ? `[Wikipedia](${web.url})` : 'Wikipedia';
      const reply =
        mode === 'EXPERT'
          ? `SYS_INTEL_FETCH // "${truncate(raw, 60)}" -> ${web.title}\n\n${body}`
          : `**${web.title}**\n${body}\n\nSource: ${src}${web.fromCache ? ' (saved)' : ''}`;
      return finish(memory, raw, reply, 'web', { topic: 'GENERAL_QA', imageUrl: web.imageUrl });
    }
    lookupFailed = true;
  }

  // Live prices / weather / news / "near me": an encyclopedia can't answer, so say so honestly.
  if (needsLiveData(raw) && !(best && best.confidence >= 0.45)) {
    logUnanswered(raw);
    return finish(
      memory,
      raw,
      mode === 'EXPERT'
        ? 'SYS_SCOPE // Live data (prices, weather, news, local listings) is outside this node. Use a search engine.'
        : "I can't check live info like current prices, weather, news or what's nearby from here — a quick web search will do better for that. I can still help with advice on repairs, design and websites, or take you to the contact section for a quote. 🙂",
      'rules',
      { suggestions: FALLBACK_SUGGESTIONS }
    );
  }

  // 8c. Smart fallback -----------------------------------------------------
  logUnanswered(raw);

  const hintShown = !!memory.userContext?.aiHintShown;
  const canHint = !hintShown && !isAIAvailable() && mode === 'HUMAN';
  const aiHint = canHint
    ? "\n\n💡 Tip: tap **ENABLE AI** at the top of this window and I can chat about almost anything."
    : '';

  if (best && best.confidence >= 0.45) {
    const reply =
      mode === 'EXPERT'
        ? `SYS_PARTIAL_MATCH // Closest module: ${best.entry.title}. ${best.entry.expert}`
        : `I'm not 100% sure what you mean, but the closest thing I can help with is **${best.entry.title.toLowerCase()}**.\n\n${best.entry.reply}${aiHint}`;
    return finish(memory, raw, reply, 'knowledge', {
      topic: best.entry.domain,
      suggestions: best.entry.suggestions,
      imageUrl: best.entry.image,
      matchedEntryId: best.entry.id,
      learn: canHint ? { aiHintShown: true } : undefined,
    });
  }

  const lookedUp = lookupFailed ? "I tried looking that up but couldn't find a reliable answer. " : '';
  const reply =
    mode === 'EXPERT'
      ? `SYS_NO_MATCH // No module matched "${truncate(raw, 60)}"${lookupFailed ? ' (web lookup: no reliable result)' : ''}. Specify: [HARDWARE] [DESIGN] [WEB].`
      : `${lookedUp}I don't have a good answer for that yet. I can help with **phone/PC repairs**, **design & branding**, and **websites** — or point you to the contact section so you can ask directly.${aiHint}`;
  return finish(memory, raw, reply, 'rules', {
    suggestions: FALLBACK_SUGGESTIONS,
    learn: canHint ? { aiHintShown: true } : undefined,
  });
}

export { isLocalLLMReady } from './localLLM';
export type { PersonaMode, SessionMemory, Message, ProcessingResult } from './types';
