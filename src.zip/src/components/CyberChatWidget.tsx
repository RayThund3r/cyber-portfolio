// src/components/CyberChatWidget.tsx
'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { useTheme } from '@/context/ThemeContext';
import { processChatQuery, isAIAvailable } from '@/utils/chatEngine';
import { PersonaMode, Message, SessionMemory, SystemAction, ResponseSource } from '@/utils/chatEngine/types';
import {
  LLMState,
  MODEL_OPTIONS,
  DEFAULT_MODEL_ID,
  getLLMState,
  subscribeLLM,
  loadLocalLLM,
  unloadLocalLLM,
  autoLoadIfPreviouslyEnabled,
  labelForModel,
} from '@/utils/chatEngine/localLLM';
import { isRemoteLLMConfigured } from '@/utils/chatEngine/remoteLLM';
import { loadSession, saveSession, getPrefs, getUnansweredQueries, recordLearnedAlias } from '@/utils/chatEngine/learningEngine';
import { SITE, FALLBACK_SUGGESTIONS } from '@/utils/chatEngine/siteConfig';

const nowTime = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

const EMPTY_MEMORY: SessionMemory = {
  interactionCount: 0,
  lastTopic: 'GREETINGS',
  userContext: {},
  conversationHistory: [],
};

/** Only built-in knowledge answers can be rated (they are what the retriever can learn from). */
function learnInfo(query: string, result: { source: ResponseSource; matchedEntryId?: string }) {
  return result.source === 'knowledge' && result.matchedEntryId
    ? { query, entryId: result.matchedEntryId }
    : undefined;
}

const WELCOME: Message = {
  id: 'welcome',
  sender: 'bot',
  text: "Hey there! 👋 I'm your interactive assistant. Ask me about phone & PC repairs, brand design, web projects — or just chat.",
  time: '',
};

const SOURCE_BADGE: Partial<Record<ResponseSource, string>> = {
  'local-ai': 'AI · ON-DEVICE',
  'remote-ai': 'AI',
  knowledge: 'KB',
  web: 'WEB',
};

/* ---------- tiny, safe markdown renderer (**bold**, `code`, - lists, 1. lists) ---------- */

function renderInline(text: string) {
  return text.split(/(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\(https:\/\/[^)\s]+\))/g).map((p, i) => {
    const link = p.match(/^\[([^\]]+)\]\((https:\/\/[^)\s]+)\)$/);
    if (link) {
      return (
        <a key={i} href={link[2]} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2 text-zinc-100 hover:text-white">
          {link[1]}
        </a>
      );
    }
    if (p.length > 4 && p.startsWith('**') && p.endsWith('**')) {
      return <strong key={i} className="font-semibold text-zinc-50">{p.slice(2, -2)}</strong>;
    }
    if (p.length > 2 && p.startsWith('`') && p.endsWith('`')) {
      return <code key={i} className="px-1 rounded bg-zinc-800 text-[11px] font-mono">{p.slice(1, -1)}</code>;
    }
    return <span key={i}>{p}</span>;
  });
}

function RichText({ text }: { text: string }) {
  const lines = text.split('\n');
  return (
    <div className="space-y-0.5">
      {lines.map((line, i) => {
        if (!line.trim()) return <div key={i} className="h-1.5" />;
        const bullet = line.match(/^\s*[-*•]\s+(.*)$/);
        if (bullet) {
          return (
            <div key={i} className="flex gap-1.5 pl-1">
              <span className="text-zinc-500">•</span>
              <span>{renderInline(bullet[1])}</span>
            </div>
          );
        }
        const num = line.match(/^\s*(\d+)[.)]\s+(.*)$/);
        if (num) {
          return (
            <div key={i} className="flex gap-1.5 pl-1">
              <span className="text-zinc-500 tabular-nums">{num[1]}.</span>
              <span>{renderInline(num[2])}</span>
            </div>
          );
        }
        return <div key={i}>{renderInline(line)}</div>;
      })}
    </div>
  );
}

export default function CyberChatWidget() {
  const themeCtx = useTheme() as any;
  const { theme, themeClasses } = themeCtx;

  const accent =
    theme === 'cyan'
      ? { dot: 'bg-cyan-400', solid: 'bg-cyan-500 text-black hover:bg-cyan-400', bar: 'bg-cyan-400', chip: 'border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/10', frame: 'border-cyan-500/50 shadow-[0_0_30px_rgba(6,182,212,0.2)]' }
      : theme === 'amber'
      ? { dot: 'bg-amber-400', solid: 'bg-amber-500 text-black hover:bg-amber-400', bar: 'bg-amber-400', chip: 'border-amber-500/40 text-amber-300 hover:bg-amber-500/10', frame: 'border-amber-500/50 shadow-[0_0_30px_rgba(245,158,11,0.2)]' }
      : { dot: 'bg-emerald-400', solid: 'bg-emerald-500 text-black hover:bg-emerald-400', bar: 'bg-emerald-400', chip: 'border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10', frame: 'border-emerald-500/50 shadow-[0_0_30px_rgba(16,185,129,0.2)]' };

  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<PersonaMode>('HUMAN');
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [memory, setMemory] = useState<SessionMemory>(EMPTY_MEMORY);
  const [messages, setMessages] = useState<Message[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>(FALLBACK_SUGGESTIONS);
  const [llm, setLlm] = useState<LLMState>({ status: 'idle', progress: 0, text: '' });
  const [modelId, setModelId] = useState<string>(DEFAULT_MODEL_ID);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const hydrated = useRef(false);

  /* ---------- mount: restore session, wire up the AI status ---------- */
  useEffect(() => {
    const saved = loadSession();
    if (saved && saved.messages.length > 0) {
      setMessages(saved.messages);
      setMemory(saved.memory);
    } else {
      setMessages([{ ...WELCOME, time: nowTime() }]);
    }
    const prefs = getPrefs();
    if (prefs.modelId) setModelId(prefs.modelId);

    setLlm(getLLMState());
    const unsub = subscribeLLM(setLlm);
    autoLoadIfPreviouslyEnabled();
    hydrated.current = true;

    // Handy for you: type  window.chatUnanswered()  in the console to see what the bot couldn't answer.
    (window as any).chatUnanswered = getUnansweredQueries;
    return unsub;
  }, []);

  /* ---------- persist ---------- */
  useEffect(() => {
    if (!hydrated.current || isThinking) return;
    if (messages.some((m) => m.streaming)) return;
    saveSession(messages, memory);
  }, [messages, memory, isThinking]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen, isThinking]);

  const pushBot = useCallback((text: string, source?: ResponseSource) => {
    setMessages((prev) => [...prev, { id: uid(), sender: 'bot', text, time: nowTime(), source }]);
  }, []);

  /* ---------- site actions ---------- */
  const runAction = useCallback(
    (action: SystemAction) => {
      if (action === 'NONE') return;
      window.dispatchEvent(new CustomEvent('chat:action', { detail: { action } }));

      if (action === 'SCROLL_TO_PROJECTS') {
        document.getElementById(SITE.projectsElementId)?.scrollIntoView({ behavior: 'smooth' });
      } else if (action === 'OPEN_CONTACT') {
        document.getElementById(SITE.contactElementId)?.scrollIntoView({ behavior: 'smooth' });
      } else if (action === 'TOGGLE_THEME') {
        const toggle = themeCtx.toggleTheme || themeCtx.cycleTheme || themeCtx.nextTheme;
        if (typeof toggle === 'function') toggle();
        else pushBot("I couldn't change the theme — the site's theme switch isn't connected to the chat yet.");
      } else if (action === 'RESET_CHAT') {
        setMessages([{ ...WELCOME, time: nowTime() }]);
        setMemory(EMPTY_MEMORY);
        setSuggestions(FALLBACK_SUGGESTIONS);
      }
    },
    [themeCtx, pushBot]
  );

  /* ---------- mode toggle ---------- */
  const toggleMode = () => {
    const next: PersonaMode = mode === 'HUMAN' ? 'EXPERT' : 'HUMAN';
    setMode(next);
    pushBot(
      next === 'EXPERT'
        ? 'SYS_MODE: [EXPERT] // Technical, compact responses enabled.'
        : 'Human mode on! 😊 Warm, conversational and simple.'
    );
  };

  /* ---------- sending ---------- */
  const handleSendMessage = async (textToSend: string) => {
    const text = textToSend.trim();
    if (!text || isThinking) return;

    setMessages((prev) => [...prev, { id: uid(), sender: 'user', text, time: nowTime() }]);
    setInput('');
    setSuggestions([]);
    setIsThinking(true);

    const ctrl = new AbortController();
    abortRef.current = ctrl;
    let streamId: string | null = null;

    try {
      const result = await processChatQuery(text, mode, memory, {
        signal: ctrl.signal,
        onToken: (partial) => {
          if (!streamId) {
            streamId = uid();
            const id = streamId;
            setMessages((prev) => [
              ...prev,
              { id, sender: 'bot', text: partial, time: nowTime(), streaming: true },
            ]);
          } else {
            const id = streamId;
            setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, text: partial } : m)));
          }
        },
      });

      setMemory(result.updatedMemory);
      setSuggestions(result.suggestions && result.suggestions.length ? result.suggestions : []);

      if (streamId) {
        const id = streamId;
        setMessages((prev) =>
          prev.map((m) =>
            m.id === id
              ? { ...m, text: result.reply, streaming: false, source: result.source, imageUrl: result.imageUrl, learn: learnInfo(text, result) }
              : m
          )
        );
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: uid(),
            sender: 'bot',
            text: result.reply,
            imageUrl: result.imageUrl,
            time: nowTime(),
            source: result.source,
            learn: learnInfo(text, result),
          },
        ]);
      }

      if (result.action) runAction(result.action);
    } catch (error) {
      console.error('Engine execution error:', error);
      pushBot(
        mode === 'EXPERT'
          ? 'SYS_ERR // Engine fault. Retry.'
          : 'Oops — something went wrong on my side. Please try again. 🙏'
      );
    } finally {
      setIsThinking(false);
      abortRef.current = null;
    }
  };

  const stopGenerating = () => abortRef.current?.abort();

  /* ---------- 👍 / 👎: teach the retriever (stored in this browser only) ---------- */
  const rateMessage = (msg: Message, rating: 'up' | 'down') => {
    if (!msg.learn || msg.rated) return;
    recordLearnedAlias(msg.learn.query, msg.learn.entryId, rating === 'up' ? 1 : -1);
    setMessages((prev) => prev.map((m) => (m.id === msg.id ? { ...m, rated: rating } : m)));
    if (rating === 'down') {
      pushBot(
        mode === 'EXPERT'
          ? 'SYS_FEEDBACK // Mismatch logged. Rephrase the query or use the contact module.'
          : "Thanks for telling me — I won't pick that answer for this question again. Could you rephrase it, or should I take you to the contact section so you can ask directly?"
      );
      setSuggestions(['Open contact section', 'Let me rephrase']);
    }
  };

  /* ---------- AI panel ---------- */
  const aiOn = llm.status === 'ready';
  const remote = isRemoteLLMConfigured();
  const selected = MODEL_OPTIONS.find((m) => m.id === modelId) || MODEL_OPTIONS[1];

  const renderAIPanel = () => {
    const base = 'px-4 py-2 bg-zinc-900/60 border-b border-zinc-800 text-[10px] font-mono';

    if (llm.status === 'loading') {
      const pct = Math.round(llm.progress * 100);
      return (
        <div className={base}>
          <div className="flex justify-between text-zinc-400 mb-1">
            <span>LOADING AI · {labelForModel(llm.modelId)}</span>
            <span>{pct}%</span>
          </div>
          <div className="h-1 bg-zinc-800 rounded overflow-hidden">
            <div className={`h-full ${accent.bar} transition-all`} style={{ width: `${pct}%` }} />
          </div>
          <div className="mt-1 text-zinc-600 truncate">{llm.text}</div>
        </div>
      );
    }

    if (aiOn) {
      return (
        <div className={`${base} flex items-center justify-between`}>
          <span className="text-emerald-400">● AI ON · {labelForModel(llm.modelId)} · runs on your device</span>
          <button onClick={() => unloadLocalLLM()} className="text-zinc-500 hover:text-zinc-200 cursor-pointer">
            TURN OFF
          </button>
        </div>
      );
    }

    if (llm.status === 'unsupported') {
      return (
        <div className={`${base} text-zinc-500`}>
          {remote
            ? '● Using server AI'
            : 'AI needs a WebGPU browser (Chrome / Edge). Using smart rules + search for now.'}
        </div>
      );
    }

    if (remote) {
      return <div className={`${base} text-emerald-400`}>● AI ON · server</div>;
    }

    return (
      <div className={base}>
        <div className="flex items-center gap-2">
          <select
            value={modelId}
            onChange={(e) => setModelId(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded px-1.5 py-1 text-zinc-300 focus:outline-none"
          >
            {MODEL_OPTIONS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label} {m.approxDownload}
              </option>
            ))}
          </select>
          <button
            onClick={() => loadLocalLLM(modelId)}
            className={`px-2 py-1 rounded font-bold cursor-pointer ${accent.solid}`}
          >
            ENABLE AI
          </button>
        </div>
        <div className="mt-1 text-zinc-600">
          {llm.status === 'error'
            ? `Couldn't load AI: ${llm.error || 'unknown error'}`
            : `${selected.note}. One-time ${selected.approxDownload} download (cached after) — use Wi-Fi if you're on mobile data.`}
        </div>
      </div>
    );
  };

  const lastBotIsStreaming = messages.length > 0 && messages[messages.length - 1].streaming;

  return (
    <div className="fixed bottom-5 right-5 z-50 font-mono">
      {/* Floating Chat Trigger Bubble */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className={`flex items-center gap-2.5 px-4 py-3 rounded-full bg-zinc-900 border ${themeClasses?.border ?? ''} text-zinc-100 shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer group`}
        >
          <span className={`w-2.5 h-2.5 rounded-full animate-ping ${accent.dot}`}></span>
          <span className="text-xs font-bold tracking-wide">CHAT_ASSIST</span>
        </button>
      )}

      {/* Expanded Chat Window */}
      {isOpen && (
        <div
          className={`w-80 sm:w-96 max-w-[calc(100vw-2.5rem)] h-[560px] max-h-[calc(100vh-2.5rem)] bg-zinc-950 border ${accent.frame} rounded-xl flex flex-col overflow-hidden animate-page-in`}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-zinc-900/90 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full animate-pulse ${accent.dot}`}></span>
              <span className={`text-xs font-bold ${themeClasses?.accent ?? ''}`}>CHAT_ENGINE</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={toggleMode}
                className={`px-2 py-0.5 rounded text-[10px] font-mono border transition-all cursor-pointer ${
                  mode === 'HUMAN'
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/20'
                    : 'bg-cyan-500/10 border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/20'
                }`}
              >
                MODE: [{mode}]
              </button>
              <button
                onClick={() => setIsOpen(false)}
                aria-label="Close chat"
                className="text-xs text-zinc-500 hover:text-zinc-200 px-1.5 py-0.5 rounded bg-zinc-800/50 hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>
          </div>

          {/* AI status / enable panel */}
          {renderAIPanel()}

          {/* Message Stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs font-sans">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                <div
                  className={`max-w-[88%] p-3 rounded-lg leading-relaxed break-words ${
                    msg.sender === 'user'
                      ? `${accent.solid.split(' hover')[0]} font-medium`
                      : 'bg-zinc-900 border border-zinc-800 text-zinc-200'
                  }`}
                >
                  {msg.imageUrl && (
                    <img
                      src={msg.imageUrl}
                      alt=""
                      loading="lazy"
                      className="w-full h-36 object-cover rounded-md mb-2 border border-zinc-700/50"
                    />
                  )}
                  {msg.sender === 'bot' ? <RichText text={msg.text} /> : <div className="whitespace-pre-wrap">{msg.text}</div>}
                  {msg.streaming && <span className="inline-block w-1.5 h-3 ml-0.5 bg-zinc-400 animate-pulse align-middle" />}
                </div>
                <span className="text-[9px] font-mono text-zinc-600 mt-1 px-1 flex items-center gap-1.5">
                  <span>
                    {msg.time}
                    {msg.source && SOURCE_BADGE[msg.source] ? ` · ${SOURCE_BADGE[msg.source]}` : ''}
                  </span>
                  {msg.learn && !msg.streaming && (
                    msg.rated ? (
                      <span>{msg.rated === 'up' ? '· 👍 thanks' : '· 👎 noted'}</span>
                    ) : (
                      <>
                        <button onClick={() => rateMessage(msg, 'up')} aria-label="Helpful" className="hover:text-zinc-200 cursor-pointer">👍</button>
                        <button onClick={() => rateMessage(msg, 'down')} aria-label="Not helpful" className="hover:text-zinc-200 cursor-pointer">👎</button>
                      </>
                    )
                  )}
                </span>
              </div>
            ))}

            {/* Thinking dots (before the first streamed token / for instant replies) */}
            {isThinking && !lastBotIsStreaming && (
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-zinc-500 bg-zinc-900/60 p-2 rounded max-w-[120px] border border-zinc-800">
                <span className={`w-1.5 h-1.5 rounded-full ${accent.dot} animate-bounce`}></span>
                <span className={`w-1.5 h-1.5 rounded-full ${accent.dot} animate-bounce [animation-delay:0.2s]`}></span>
                <span className={`w-1.5 h-1.5 rounded-full ${accent.dot} animate-bounce [animation-delay:0.4s]`}></span>
              </div>
            )}

            {/* Quick replies */}
            {!isThinking && suggestions.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => handleSendMessage(s)}
                    className={`px-2.5 py-1 rounded-full border text-[11px] transition-colors cursor-pointer ${accent.chip}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            <div ref={chatEndRef} />
          </div>

          {/* Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(input);
            }}
            className="p-3 bg-zinc-900/90 border-t border-zinc-800 flex gap-2"
          >
            <input
              type="text"
              placeholder={mode === 'HUMAN' ? 'Ask anything...' : 'ENTER_QUERY...'}
              value={input}
              maxLength={600}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 min-w-0 bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-xs text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-zinc-700"
            />
            {isThinking && (isAIAvailable() || lastBotIsStreaming) ? (
              <button
                type="button"
                onClick={stopGenerating}
                className="px-3.5 py-2 rounded text-xs font-mono font-bold bg-zinc-700 text-zinc-100 hover:bg-zinc-600 transition-all cursor-pointer"
              >
                STOP
              </button>
            ) : (
              <button
                type="submit"
                disabled={isThinking}
                className={`px-3.5 py-2 rounded text-xs font-mono font-bold transition-all cursor-pointer disabled:opacity-50 ${accent.solid}`}
              >
                SEND
              </button>
            )}
          </form>
        </div>
      )}
    </div>
  );
}
